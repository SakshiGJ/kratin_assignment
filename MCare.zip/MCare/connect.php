<?php
$con = mysqli_connect("localhost", "root", "", "2016bcs040");
?>