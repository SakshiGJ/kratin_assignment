<?php 
$conn=mysqli_connect("localhost","root","","2016bcs040")or die("Can't Connect...");
	
?>